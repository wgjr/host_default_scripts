<?php
/**
 * Single signon for phpMyAdmin
 *
 * This is just example how to use session based single signon with
 * phpMyAdmin, it is not intended to be perfect code and look, only
 * shows how you can integrate this functionality in your application.
 */

/* Use cookies for session */
ini_set('session.use_cookies', 'true');
/* Change this to true if using phpMyAdmin over https */
$secureCookie = false;
/* Need to have cookie visible from parent directory */
session_set_cookie_params(0, '/', '', $secureCookie, true);
/* Create signon session */
$sessionName = 'SignonSession';
session_name($sessionName);
// Uncomment and change the following line to match your $cfg['SessionSavePath']
//session_save_path('/foobar');
@session_start();


if (!isset($_GET['user']) and !isset($_GET['pass'])) {
    $titleHTML = 'Falha na autenticação';
    $textHTML = 'Realize novamente o acesso através do seu <a href="https://cloud.hospedafacil.com">Gerenciador do Cloud</a>. ';
} else {
    $curl = curl_init();

    $fields = array(
        'auth_user' => $_GET['user'],
        'auth_pass' => $_GET['pass'],
    );

    curl_setopt_array($curl, array(
        CURLOPT_URL => "https://api.hospedafacil.com/api/v1/script/phpmyadmin/login",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($fields),
        CURLOPT_HTTPHEADER => array(
            "Accept: */*",
            "Accept-Encoding: gzip, deflate",
            "Cache-Control: no-cache",
            "Connection: keep-alive",
            "Content-Type: application/json",
            "cache-control: no-cache",
        ),
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        $titleHTML = 'Falha na autenticação';
        $textHTML = 'Realize novamente o acesso através do seu <a href="https://cloud.hospedafacil.com">Gerenciador do Cloud</a>.';
    } else {
        $dataJson = json_decode($response);

        if (isset($dataJson->auth_user) and isset($dataJson->auth_pass)) {
            session_name('PHPSESSID');

            $_SESSION['PMA_single_signon_user'] = $dataJson->auth_user;
            $_SESSION['PMA_single_signon_password'] = $dataJson->auth_pass;

            if (!isset($_SESSION['PMA_single_signon_token'])) {
                $_SESSION['PMA_single_signon_token'] = md5(uniqid(rand(), true));
            }
            $_SESSION['PMA_single_signon_HMAC_secret'] = hash('sha1', uniqid(strval(random_int(0, mt_getrandmax())), true));


            $id = session_id();

            $hostname = $_SERVER['SERVER_NAME'];

            $id = session_id();
            /* Close that session */
            @session_write_close();
            /* Redirect to phpMyAdmin (should use absolute URL here!) */
            header('Location: ../index.php');
        } else {
            $titleHTML = 'Acesso não autorizado';
            $textHTML = 'Realize novamente o acesso através do seu <a href="https://cloud.hospedafacil.com">Gerenciador do Cloud</a>.';
        }
    }
}
?>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>phpMyAdmin</title>
    <link rel="stylesheet" href="https://unpkg.com/chota@latest">
</head>

<body>
    <div id="top" class="container" role="document">
        <main role="main">
            <section id="text">
                <div class="row">
                    <div class="col">  </div>
                    <div class="col is-center">
                        <h1><?php echo $titleHTML; ?></h1> 
                    </div>
                    <div class="col">  </div>

                </div>
                <div class="row">
                    <div class="col">  </div>
                    <div class="col"> <p><?php echo $textHTML; ?></p> </div>
                    <div class="col">  </div>
                </div>
            </section>
        </main>
    </div>
</body>

</html>